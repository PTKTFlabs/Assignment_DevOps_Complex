
# Root module wiring child modules

variable "location" { type = string }
variable "env" { type = string }
variable "resource_group_name" { type = string }
variable "tags" { type = map(string) default = {} }
variable "sql_admin_login" { type = string }
variable "sql_admin_password" { type = string }

resource "azurerm_resource_group" "rg" {
  name     = var.resource_group_name
  location = var.location
  tags     = var.tags
}

module "network" {
  source              = "./modules/network"
  name_prefix         = "${var.env}-web"
  location            = var.location
  resource_group_name = azurerm_resource_group.rg.name
  tags                = var.tags
}

module "keyvault" {
  source              = "./modules/keyvault"
  name_prefix         = "${var.env}-kv"
  location            = var.location
  resource_group_name = azurerm_resource_group.rg.name
  tenant_id           = data.azurerm_client_config.current.tenant_id
  use_rbac            = true
  tags                = var.tags
}

data "azurerm_client_config" "current" {}

module "appservice" {
  source                 = "./modules/appservice"
  name_prefix            = "${var.env}-app"
  location               = var.location
  resource_group_name    = azurerm_resource_group.rg.name
  subnet_id              = module.network.subnet_ids["apps"]
  workspace_id           = module.monitoring.log_analytics_id
  kv_id                  = module.keyvault.kv_id
  tags                   = var.tags
}

module "sql" {
  source                 = "./modules/sql"
  name_prefix            = "${var.env}-sql"
  location               = var.location
  resource_group_name    = azurerm_resource_group.rg.name
  administrator_login    = var.sql_admin_login
  administrator_password = var.sql_admin_password
  tags                   = var.tags
}

# Store DB connection string as a secret in Key Vault
resource "azurerm_key_vault_secret" "db_connection" {
  name         = "db-connection-string"
  value        = module.sql.connection_string
  key_vault_id = module.keyvault.kv_id
}

module "monitoring" {
  source              = "./modules/monitoring"
  name_prefix         = "${var.env}-mon"
  location            = var.location
  resource_group_name = azurerm_resource_group.rg.name
  tags                = var.tags
  monitored_resource_ids = [
    module.appservice.frontend_id,
    module.appservice.backend_id,
    module.sql.sql_server_id,
    module.keyvault.kv_id
  ]
}

# Grant Web Apps managed identities access to read secrets from Key Vault
resource "azurerm_role_assignment" "frontend_kv_reader" {
  scope                = module.keyvault.kv_id
  role_definition_name = "Key Vault Secrets User"
  principal_id         = module.appservice.frontend_principal_id
}

resource "azurerm_role_assignment" "backend_kv_reader" {
  scope                = module.keyvault.kv_id
  role_definition_name = "Key Vault Secrets User"
  principal_id         = module.appservice.backend_principal_id
}

output "frontend_url" { value = module.appservice.frontend_default_hostname }
output "backend_url"  { value = module.appservice.backend_default_hostname }
output "key_vault_name" { value = module.keyvault.kv_name }
output "log_analytics_workspace_id" { value = module.monitoring.log_analytics_id }
