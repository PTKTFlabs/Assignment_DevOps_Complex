
location            = "eastus"
env                 = "dev"
resource_group_name = "rg-dev-webapp"
sql_admin_login     = "sqladminuser"
sql_admin_password  = "P@ssword1234!"
tags = { env = "dev", owner = "devops" }
