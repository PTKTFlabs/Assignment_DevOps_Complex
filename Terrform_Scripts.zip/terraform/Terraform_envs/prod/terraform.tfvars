
location            = "eastus"
env                 = "prod"
resource_group_name = "rg-prod-webapp"
sql_admin_login     = "sqladminuser"
sql_admin_password  = "ChangeThis!Strong#Prod123"
tags = { env = "prod", owner = "devops" }
