
variable "name_prefix" { type = string }
variable "location" { type = string }
variable "resource_group_name" { type = string }
variable "administrator_login" { type = string }
variable "administrator_password" { type = string }
variable "tags" { type = map(string) default = {} }

resource "random_string" "suffix" { length = 5 special = false upper = false }

resource "azurerm_mssql_server" "sql" {
  name                         = replace("${var.name_prefix}-${random_string.suffix.result}", "_", "-")
  resource_group_name          = var.resource_group_name
  location                     = var.location
  version                      = "12.0"
  administrator_login          = var.administrator_login
  administrator_login_password = var.administrator_password
  minimum_tls_version          = "1.2"
  public_network_access_enabled = true
  tags                         = var.tags
}

resource "azurerm_mssql_database" "db" {
  name           = "appdb"
  server_id      = azurerm_mssql_server.sql.id
  sku_name       = "S0"
  zone_redundant = false
  tags           = var.tags
}

# Allow Azure services (including App Service) to connect
resource "azurerm_mssql_firewall_rule" "allow_azure" {
  name             = "AllowAzure"
  server_id        = azurerm_mssql_server.sql.id
  start_ip_address = "0.0.0.0"
  end_ip_address   = "0.0.0.0"
}

locals {
  connection_string = "Server=tcp:${azurerm_mssql_server.sql.fully_qualified_domain_name},1433;Initial Catalog=${azurerm_mssql_database.db.name};Persist Security Info=False;User ID=${var.administrator_login};Password=${var.administrator_password};MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;"
}

output "connection_string" { value = local.connection_string sensitive = true }
output "sql_server_id"     { value = azurerm_mssql_server.sql.id }
