
variable "name_prefix" { type = string }
variable "location" { type = string }
variable "resource_group_name" { type = string }
variable "subnet_id" { type = string }
variable "workspace_id" { type = string }
variable "kv_id" { type = string }
variable "tags" { type = map(string) default = {} }

resource "azurerm_service_plan" "asp" {
  name                = "${var.name_prefix}-plan"
  location            = var.location
  resource_group_name = var.resource_group_name
  os_type             = "Linux"
  sku_name            = "P1v3"
  tags                = var.tags
}

# Workspace-based Application Insights
resource "azurerm_application_insights" "appi" {
  name                = "${var.name_prefix}-appi"
  location            = var.location
  resource_group_name = var.resource_group_name
  application_type    = "web"
  workspace_id        = var.workspace_id
  tags                = var.tags
}

# Frontend Web App with slot
resource "azurerm_linux_web_app" "frontend" {
  name                = "${var.name_prefix}-fe"
  location            = var.location
  resource_group_name = var.resource_group_name
  service_plan_id     = azurerm_service_plan.asp.id
  https_only          = true
  tags                = var.tags

  site_config {
    application_stack {
      node_version = "20-lts"
    }
    always_on = true
  }

  identity {
    type = "SystemAssigned"
  }

  app_settings = {
    "WEBSITE_RUN_FROM_PACKAGE" = "1"
    "APPLICATIONINSIGHTS_CONNECTION_STRING" = azurerm_application_insights.appi.connection_string
    # Key Vault reference for DB connection string; the secret itself is created in root
    "DB_CONNECTION_STRING" = "@Microsoft.KeyVault(SecretUri=${replace(replace(var.kv_id, "/providers/Microsoft.KeyVault/vaults/", "https://"), "/", ".vault.azure.net/")}/secrets/db-connection-string)"
  }
}

resource "azurerm_linux_web_app_slot" "frontend_staging" {
  name           = "staging"
  app_service_id = azurerm_linux_web_app.frontend.id

  site_config {
    application_stack {
      node_version = "20-lts"
    }
    always_on = true
  }
}

# Backend Web App with slot
resource "azurerm_linux_web_app" "backend" {
  name                = "${var.name_prefix}-be"
  location            = var.location
  resource_group_name = var.resource_group_name
  service_plan_id     = azurerm_service_plan.asp.id
  https_only          = true
  tags                = var.tags

  site_config {
    application_stack {
      node_version = "20-lts"
    }
    always_on = true
  }

  identity {
    type = "SystemAssigned"
  }

  app_settings = {
    "WEBSITE_RUN_FROM_PACKAGE" = "1"
    "APPLICATIONINSIGHTS_CONNECTION_STRING" = azurerm_application_insights.appi.connection_string
    "DB_CONNECTION_STRING" = "@Microsoft.KeyVault(SecretUri=${replace(replace(var.kv_id, "/providers/Microsoft.KeyVault/vaults/", "https://"), "/", ".vault.azure.net/")}/secrets/db-connection-string)"
  }
}

resource "azurerm_linux_web_app_slot" "backend_staging" {
  name           = "staging"
  app_service_id = azurerm_linux_web_app.backend.id

  site_config {
    application_stack {
      node_version = "20-lts"
    }
    always_on = true
  }
}

output "frontend_id"               { value = azurerm_linux_web_app.frontend.id }
output "backend_id"                { value = azurerm_linux_web_app.backend.id }
output "frontend_principal_id"     { value = azurerm_linux_web_app.frontend.identity[0].principal_id }
output "backend_principal_id"      { value = azurerm_linux_web_app.backend.identity[0].principal_id }
output "frontend_default_hostname"  { value = azurerm_linux_web_app.frontend.default_hostname }
output "backend_default_hostname"   { value = azurerm_linux_web_app.backend.default_hostname }
