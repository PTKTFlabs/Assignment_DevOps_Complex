
variable "name_prefix" { type = string }
variable "location" { type = string }
variable "resource_group_name" { type = string }
variable "tags" { type = map(string) default = {} }
variable "monitored_resource_ids" { type = list(string) }

resource "azurerm_log_analytics_workspace" "law" {
  name                = "${var.name_prefix}-law"
  location            = var.location
  resource_group_name = var.resource_group_name
  sku                 = "PerGB2018"
  retention_in_days   = 30
  tags                = var.tags
}

# Diagnostic settings to route logs/metrics to LAW
resource "azurerm_monitor_diagnostic_setting" "diag" {
  for_each                   = toset(var.monitored_resource_ids)
  name                       = "send-to-law"
  target_resource_id         = each.value
  log_analytics_workspace_id = azurerm_log_analytics_workspace.law.id

  enabled_log {
    category = "AppServiceHTTPLogs"
  }
  enabled_log {
    category = "AppServiceConsoleLogs"
  }
  metric {
    category = "AllMetrics"
    enabled  = true
  }
}

# Action Group (email placeholder)
resource "azurerm_monitor_action_group" "ops" {
  name                = "${var.name_prefix}-ag"
  resource_group_name = var.resource_group_name
  short_name          = "opsag"

  email_receiver {
    name          = "oncall"
    email_address = "oncall@example.com"
  }
}

# Alerts: App Service CPU and 5xx
resource "azurerm_monitor_metric_alert" "cpu_high" {
  name                = "${var.name_prefix}-cpu-high"
  resource_group_name = var.resource_group_name
  scopes              = var.monitored_resource_ids
  description         = "CPU > 80% for 10 minutes"
  severity            = 3
  frequency           = "PT5M"
  window_size         = "PT10M"
  criteria {
    metric_namespace = "Microsoft.Web/sites"
    metric_name      = "PercentCpu"
    aggregation      = "Average"
    operator         = "GreaterThan"
    threshold        = 80
  }
  action {
    action_group_id = azurerm_monitor_action_group.ops.id
  }
}

resource "azurerm_monitor_metric_alert" "http5xx" {
  name                = "${var.name_prefix}-http5xx"
  resource_group_name = var.resource_group_name
  scopes              = var.monitored_resource_ids
  description         = "HTTP 5xx > 10 in 5 minutes"
  severity            = 3
  frequency           = "PT5M"
  window_size         = "PT5M"
  criteria {
    metric_namespace = "Microsoft.Web/sites"
    metric_name      = "Http5xx"
    aggregation      = "Total"
    operator         = "GreaterThan"
    threshold        = 10
  }
  action {
    action_group_id = azurerm_monitor_action_group.ops.id
  }
}

output "log_analytics_id" { value = azurerm_log_analytics_workspace.law.id }
