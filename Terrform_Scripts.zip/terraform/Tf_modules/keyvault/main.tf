
variable "name_prefix" { type = string }
variable "location" { type = string }
variable "resource_group_name" { type = string }
variable "tenant_id" { type = string }
variable "use_rbac" { type = bool default = true }
variable "tags" { type = map(string) default = {} }

resource "random_string" "suffix" { length = 5 special = false upper = false }

resource "azurerm_key_vault" "kv" {
  name                        = replace("${var.name_prefix}-${random_string.suffix.result}", "_", "-")
  location                    = var.location
  resource_group_name         = var.resource_group_name
  tenant_id                   = var.tenant_id
  sku_name                    = "standard"
  purge_protection_enabled    = true
  soft_delete_retention_days  = 7
  public_network_access_enabled = true
  enable_rbac_authorization   = var.use_rbac
  tags                        = var.tags
}

output "kv_id"   { value = azurerm_key_vault.kv.id }
output "kv_name" { value = azurerm_key_vault.kv.name }
